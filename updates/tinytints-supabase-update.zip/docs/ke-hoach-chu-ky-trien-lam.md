# Kế hoạch: Chữ ký & Hội trường triển lãm (đang bàn, chưa code)

## Phần 1 — Chữ ký (ĐÃ CHỐT — ĐÃ LÀM ở Đợt 1)

| Nội dung | Chốt |
|---|---|
| Tạo chữ ký | Trong trang cá nhân, mục "Tạo chữ ký": gõ biệt danh → chọn mẫu → lưu làm **chữ ký mặc định** |
| Tên trên chữ ký | Bé tự gõ: **tên thật hay biệt danh đều được** (mặc định gợi ý biệt danh), lọc từ xấu |
| 10 mẫu | 5 mẫu Free (gọn, bình thường) + 5 mẫu "wow" (ánh kim, vương miện, cầu vồng…) chỉ mở khi có **gói tháng**; bé Free vẫn thấy mẫu wow kèm ổ khóa |
| Tự ký bằng tay | Có, **miễn phí** (nét thường, không hiệu ứng) |
| Đổi chữ ký | Chỉ đổi ở mục "Tạo chữ ký"; tranh đã ký giữ nguyên chữ ký cũ |
| Hết hạn gói tháng | Tranh đã ký bằng mẫu wow giữ nguyên; chữ ký mặc định tự về mẫu Free cho tranh mới |
| Trong bộ công cụ vẽ | Nút "Chữ ký" cạnh xô/cọ/tẩy/sticker: bấm là chữ ký mặc định hiện lên tranh, không đổi mẫu ở đây |
| Đặt lên tranh | Kéo tự do + 4 nút góc nhanh, thanh to/nhỏ, xoay nhẹ, chọn màu mực |
| Luật | Giới hạn kích thước (tối đa ~1/4 bề ngang), không ra ngoài mép, luôn nằm trên cùng, tự có viền cho dễ đọc |
| Số lượng | Mỗi tranh 1 chữ ký; bấm lại là chỉnh chữ ký đang có |
| Khóa | Khóa khi tranh đưa ra triển lãm / đấu giá |
| Đấu trường | Chữ ký là lớp riêng, máy chấm bỏ qua — không ảnh hưởng điểm |
| Xuất file | Chữ ký có trong PNG/PDF, lịch sử tranh, triển lãm |

## Phần 2 — Hội trường triển lãm (ĐÃ CHỐT — ĐÃ LÀM ở Đợt 2)

| Nội dung | Chốt |
|---|---|
| Kiểu hội trường | **Một hội trường chung** (không còn chia phòng S/A/B): tường tranh ở sảnh, bấm tranh để phóng to xem chữ ký, tác giả |
| Tương tác | **Chỉ thả cảm xúc tích cực**: ❤️ Tim, 🎉 Hoan hô, 👏 Vỗ tay, 😍 Rất đẹp, 🌟 Tuyệt vời. Không có biểu tượng buồn/giận |
| Bình luận | **Không có bình luận** — giữ tâm lý tích cực, vui vẻ cho trẻ |
| Tranh được vào | Mọi tranh tô ở chế độ **Sáng tạo** (kể cả tranh thẻ hiếm và tranh chủ đề). Tranh "Tô theo mẫu" **không** được vào |
| Lịch vòng triển lãm (cố định 1 tuần, không có tùy chọn) | **Thứ 2 → Chủ nhật**: trưng tranh vòng hiện tại. **Thứ 7 + Chủ nhật**: vẫn trưng, đồng thời mở cổng gửi tranh cho vòng sau. **Chủ nhật 20:00**: chốt vòng. **Thứ 2 00:00**: mở vòng mới. Hội trường không bao giờ trống |
| Kết thúc vòng | Tranh tự về bộ sưu tập, mang theo **bảng cảm xúc** đã nhận (thành tích triển lãm). Tranh được thả nhiều nhất tuần nhận danh hiệu 🏆 **"Tranh được yêu thích nhất tuần"** (khung/ruy băng đi theo tranh mãi mãi) |
| Luật thả cảm xúc | Mỗi người thả cho mỗi tranh 1 cảm xúc (đổi được); không tự thả cho tranh mình; chỉ tài khoản đã xác minh mới được thả |
| Tâm lý tích cực | Tranh nào cũng có sẵn 1 lời khen của linh vật (không hiện "0"); không có bảng "ít tim nhất"; thông báo cảm xúc gom mỗi ngày 1 lần |
| Liên kết đấu giá | Tranh có thành tích triển lãm là tranh bé có thể đem đi đấu giá (bàn ở Phần 3) |
| Vinh danh mỗi tuần | **1 tranh mỗi tuần**: 🏆 "Tranh được yêu thích nhất tuần". Tính theo **tổng số cảm xúc** — 5 loại tính điểm như nhau (VD 3 ❤️ + 2 👏 = 5 điểm) |
| Đồng hạng | Nếu bằng số cảm xúc với tranh cao nhất thì **đồng hạng, cùng được trao danh hiệu**. Tuần không có tranh nào được thả cảm xúc thì không trao |
| Khóa khi xét | **Chủ nhật 20:00 (giờ Việt Nam) khóa thả cảm xúc** trên toàn hội trường, không thả/đổi/gỡ được nữa, rồi mới xét danh hiệu — đảm bảo công bằng |
| Cách gửi | **Bé tự gửi**, từ trang **Bộ sưu tập** (nâng cấp thêm tab chứa toàn bộ tranh đã hoàn thành, gồm mọi tranh hoàn thành; tranh đủ điều kiện có chú thích "✨ Đủ điều kiện triển lãm"). Nút "🏛️ Gửi triển lãm" chỉ sáng vào thứ 7 + chủ nhật |
| Điều kiện gửi | Tranh đã tô xong, **bắt buộc đã ký tên**, tô ở chế độ Sáng tạo. Bảng xác nhận báo chữ ký sẽ bị khóa |
| Số tranh mỗi vòng | **Free: 1 tranh**, **Gói tháng: 3 tranh** |
| Rút tranh | Rút được trong thứ 7 + chủ nhật; **từ thứ 2 không rút được** |
| Số lần triển lãm | Mỗi tranh **chỉ đi triển lãm 1 lần** |
| Kiểm duyệt | Tranh gửi vào hàng chờ duyệt của admin (thứ 7 + CN); tranh bị loại nhận thông báo nhẹ nhàng "Tranh này chưa phù hợp để triển lãm, bé thử gửi tranh khác nhé!" |

### Nội quy triển lãm (ĐÃ CHỐT — chỉ hiển thị bản dành cho bé)

*Gấu Bông nhắc nhỏ: tranh đi triển lãm cần đủ 8 điều này nha!* 🐻

1. ✍️ **Có chữ ký của bé** trên tranh.
2. ✅ **Tô gần xong hết tranh** (ít nhất 8/10 phần).
3. 🃏 **Tô ở chế độ Sáng tạo**: tranh thẻ hiếm hay tranh chủ đề đều được, miễn tô ở chế độ Sáng tạo.
4. 🔁 **Mỗi tranh chỉ đi triển lãm 1 lần.**
5. ~~🎨 Tô gọn gàng, không lem~~ — **đã bỏ** (tô tay khóa vùng nên không thể lem).
6. 😊 **Tranh vui vẻ, thân thiện**: không hình bậy, đáng sợ hay đánh nhau.
7. 🔤 **Không viết chữ xấu**, không ghi số điện thoại hay địa chỉ nhà.
8. 🖍️ **Tô bằng cả tấm lòng**, không tô vội cho xong.

📅 Gửi tranh vào **thứ 7 và chủ nhật** — tranh được trưng **cả tuần sau**.

Hiển thị: nút "📜 Nội quy" ở sảnh hội trường + trong bảng xác nhận gửi tranh (ô "Bé đã đọc nội quy", chỉ hỏi lần đầu). Khi bị loại, thông báo nêu đúng điều vi phạm kèm lời động viên của Gấu.

### Quy tắc vận hành (nội bộ, KHÔNG hiển thị — máy/admin làm theo)

- Giờ: theo giờ Việt Nam (GMT+7) của máy chủ. **Đóng cổng gửi tranh lúc CN 20:00** (cùng lúc khóa cảm xúc); admin duyệt tới 23:59; tranh chưa duyệt kịp tự chuyển sang vòng sau, giữ lượt.
- Điều 2 (tô xong): ≥ 80% số vùng đã tô.
- Điều 5 (lem): **đã bỏ** — nét tô tay bị khóa trong vùng nên không còn lem.
- Điều 8 (tô vội): loại nếu thời gian tô < 20 giây hoặc < 0,7 giây mỗi vùng đã tô (dùng lại luật chống gian lận có sẵn).
- Điều 1–5, 8: máy tự kiểm. Điều 6–7: admin xem.
- Tự duyệt: tranh không/ít nét cọ tự do, hoặc tác giả đã có 3 tranh liên tiếp được duyệt và chưa từng vi phạm điều 6–7. Còn lại vào hàng chờ; trang duyệt dạng lưới có nút "Duyệt tất cả"; loại tranh phải chọn số điều vi phạm.
- Tranh bị loại/rút không tính vào lượt gửi; được gửi tranh khác thay trong cùng cuối tuần. Rút được tới CN 20:00 (rút thì mở khóa chữ ký).
- Nút "🚩 Báo cho Gấu" (kín đáo, ẩn danh): bị báo nhiều thì tạm ẩn chờ admin; vi phạm thì gỡ, không xét danh hiệu, không ghi thành tích.
- Tranh thẻ hiếm tô ở chế độ Sáng tạo: xét theo **hạng thẻ**.
- Admin được hủy cảm xúc bất thường (nhiều tài khoản mới cùng thả) và thu hồi danh hiệu nếu gian lận.
- Tranh luôn thuộc về tác giả; chữ ký, bảng cảm xúc, danh hiệu đi theo tranh mãi mãi.

## Phần 3 — Đấu giá: ĐÃ BỎ

Quyết định không làm đấu giá. Lý do: bé sẽ không muốn bán tác phẩm do chính mình tạo ra, nhất là tranh đã có thành tích — giữ lại để khoe và chia sẻ có ý nghĩa hơn; đấu giá cũng làm hệ thống phức tạp (kinh tế Ruby, gian lận, tranh chấp) mà không mang lại thu nhập. Nguồn thu vẫn **chỉ từ gói dịch vụ**, không bán Ruby.

## Phần 3 (mới) — Khoe & chia sẻ tranh (ĐÃ CHỐT — ĐÃ LÀM ở Đợt 3)

| Tính năng | Nội dung |
|---|---|
| 🏅 Tủ kính thành tích | Mục mới trong trang cá nhân: trưng các tranh đã đi triển lãm, kèm bảng cảm xúc và danh hiệu 🏆. Ai xem trang cá nhân của bé cũng thấy |
| 📜 Giấy khen | Tranh đạt danh hiệu được tạo giấy khen (PDF tải về/in): hình tranh, chữ ký của bé, dòng "Tranh được yêu thích nhất tuần …". Dùng lại công cụ tạo PDF có sẵn |
| 📤 Nút "Khoe tranh" | Tạo 1 ảnh đẹp (khung + chữ ký + logo web) để tải về / gửi người thân qua Zalo, Facebook. Có cho mọi tranh đã hoàn thành; tranh có thành tích thì ảnh kèm huy hiệu |

## Phần 4 — An toàn trẻ em & phụ huynh: KHÔNG CẦN RIÊNG

Đã bỏ đấu giá và không bán Ruby → không có tiền/mua bán giữa các bé. Các biện pháp an toàn đã nằm sẵn trong Phần 2 (chỉ cảm xúc tích cực, không bình luận, kiểm duyệt, nút "Báo cho Gấu").
