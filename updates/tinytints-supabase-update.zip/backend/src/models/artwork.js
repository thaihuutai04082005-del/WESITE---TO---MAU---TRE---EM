import { DEFAULT_ARTWORK_FRAME } from '../config/constants.js';
import { getDb, parseJson } from '../config/db.js';

export const findById = async (id) => await getDb().prepare('SELECT * FROM artworks WHERE id = ?').get(id);

export async function create({ userId, pictureId, mode, data, thumbnail = null, status = 'in_progress' }) {
  const res = await getDb()
    .prepare('INSERT INTO artworks (user_id, picture_id, mode, data, thumbnail, status, completed_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .run(
      userId,
      pictureId,
      mode,
      JSON.stringify(data || { fills: {}, strokes: [], stickers: [] }),
      thumbnail,
      status,
      status === 'completed' ? new Date().toISOString() : null,
    );
  return await findById(Number(res.lastInsertRowid));
}

export async function listByUser(userId, { status, mode } = {}) {
  let sql = `SELECT a.id, a.picture_id, a.mode, a.status, a.thumbnail, a.artwork_frame, a.created_at, a.updated_at, a.completed_at,
      p.name_vi, p.name_en, p.slug, p.is_card, p.rarity
    FROM artworks a JOIN pictures p ON p.id = a.picture_id WHERE a.user_id = ?`;
  const args = [userId];
  if (status) {
    sql += ' AND a.status = ?';
    args.push(status);
  }
  if (mode) {
    sql += ' AND a.mode = ?';
    args.push(mode);
  }
  sql += ' ORDER BY a.updated_at DESC LIMIT 500';
  return (
    await getDb()
      .prepare(sql)
      .all(...args)
  ).map(toSummary);
}

export function toSummary(a) {
  return {
    id: a.id,
    pictureId: a.picture_id,
    mode: a.mode,
    status: a.status,
    thumbnail: a.thumbnail,
    // Chưa chọn khung (null) → tranh hoàn thành dùng khung gỗ mặc định; '' = bé chủ động bỏ khung.
    frame: a.artwork_frame === '' ? null : a.artwork_frame || (a.status === 'completed' ? DEFAULT_ARTWORK_FRAME : null),
    name: { vi: a.name_vi, en: a.name_en },
    isCard: !!a.is_card,
    rarity: a.rarity,
    createdAt: a.created_at,
    updatedAt: a.updated_at,
    completedAt: a.completed_at,
  };
}

export const dataOf = (a) => parseJson(a.data, { fills: {}, strokes: [], stickers: [], glitter: [] });
