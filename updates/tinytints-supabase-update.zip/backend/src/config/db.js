// Kết nối SQLite (node:sqlite có sẵn trong Node ≥ 22.5) + chạy migration trong database/migrations.
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync, readdirSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { DatabaseAdapter } from './databaseAdapter.js';
import { createPostgresPool, migratePostgres } from './postgres.js';
import { env, REPO_ROOT } from './env.js';

let db;

export function openDb(file = env.dbFile) {
  if (file !== ':memory:') mkdirSync(dirname(file), { recursive: true });
  const conn = new DatabaseSync(file);
  conn.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
  migrate(conn);
  return conn;
}

export function migrate(conn) {
  conn.exec('CREATE TABLE IF NOT EXISTS _migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL)');
  const dir = join(REPO_ROOT, 'database', 'migrations');
  const done = new Set(
    conn
      .prepare('SELECT name FROM _migrations')
      .all()
      .map((r) => r.name),
  );
  for (const name of readdirSync(dir)
    .filter((f) => f.endsWith('.sql'))
    .sort()) {
    if (done.has(name)) continue;
    const sql = readFileSync(join(dir, name), 'utf8');
    // Migration dựng lại bảng (đổi CHECK…) ghi "-- @foreign_keys off": tắt khoá ngoại trong lúc chạy
    // (theo hướng dẫn ALTER TABLE của SQLite), rồi kiểm tra toàn vẹn trước khi COMMIT.
    const fkOff = sql.includes('-- @foreign_keys off');
    if (fkOff) conn.exec('PRAGMA foreign_keys = OFF');
    conn.exec('BEGIN');
    try {
      conn.exec(sql);
      if (fkOff && conn.prepare('PRAGMA foreign_key_check').all().length) throw new Error('vi phạm khoá ngoại');
      conn.prepare('INSERT INTO _migrations (name, applied_at) VALUES (?, ?)').run(name, new Date().toISOString());
      conn.exec('COMMIT');
    } catch (err) {
      conn.exec('ROLLBACK');
      throw new Error(`Migration ${name} lỗi: ${err.message}`);
    } finally {
      if (fkOff) conn.exec('PRAGMA foreign_keys = ON');
    }
  }
}

export function getDb() {
  if (!db)
    db = env.databaseUrl
      ? new DatabaseAdapter({ pool: createPostgresPool(env.databaseUrl, env.databasePassword) })
      : new DatabaseAdapter({ sqlite: openDb() });
  return db;
}

/** Dùng trong test: thay DB mặc định. */
export function setDb(conn) {
  db = conn instanceof DatabaseAdapter ? conn : new DatabaseAdapter({ sqlite: conn });
}

/** Chạy fn trong một transaction; tự rollback khi lỗi. */
export async function tx(fn) {
  return getDb().transaction(fn);
}

export async function initializeDatabase() {
  const conn = getDb();
  if (conn.dialect === 'postgres') await migratePostgres(conn.pool);
  return conn;
}

export const now = () => new Date().toISOString();
export const parseJson = (s, fallback = null) => {
  if (s == null) return fallback;
  try {
    return JSON.parse(s);
  } catch {
    return fallback;
  }
};
