import { bindSocketHandlers } from '../utils/socketHandlers.js';
// Tô màu cùng nhau theo thời gian thực (Mục 10.1): 2–4 bé, chỉ vào qua mã phòng riêng, không có danh sách phòng công khai.
import { COLLAB_MAX_PLAYERS } from '../config/constants.js';
import * as Picture from '../models/picture.js';
import * as Artwork from '../models/artwork.js';
import * as User from '../models/user.js';
import { sanitizeArtworkData } from './scoringEngine.js';
import * as progression from './progression.js';
import { canUsePicture } from '../controllers/picture.controller.js';
import { areFriends } from '../controllers/social.controller.js';
import { randomCode } from '../utils/ids.js';

const rooms = new Map();
const userRoom = new Map();
const MAX_OPS = 5000;
const EMPTY_ROOM_GRACE_MS = 60000; // phòng vắng người được giữ 60 giây
// Mời bạn bè vào phòng: mỗi lượt mời cách nhau ≥ 3 giây; bạn bấm "Từ chối + chặn" thì người mời không mời được bạn trong 5 phút.
const INVITE_GAP_MS = 3000;
const INVITE_BLOCK_MS = 5 * 60 * 1000;
const lastInvite = new Map(); // "người mời:người được mời" → thời điểm mời gần nhất
const inviteBlocks = new Map(); // "người mời:người được mời" → hết chặn lúc

function stateOf(room) {
  // Dựng lại trạng thái tranh từ nhật ký thao tác (phục vụ Undo theo từng bé).
  const data = { fills: {}, strokes: [], stickers: [], glitter: [] };
  for (const op of room.ops) {
    if (op.type === 'fill') data.fills[op.regionId] = op.color;
    else if (op.type === 'stroke') {
      data.strokes.push(op.stroke);
      // Nét tô tay có thể kèm "vùng vừa đủ độ phủ" (ghi màu vùng) hoặc "gỡ màu vùng" khi tẩy bớt.
      if (op.fill) {
        if (op.fill.color) data.fills[op.fill.regionId] = op.fill.color;
        else delete data.fills[op.fill.regionId];
      }
    } else if (op.type === 'sticker') data.stickers.push(op.sticker);
    else if (op.type === 'sticker-update') {
      if (data.stickers[op.index]) data.stickers[op.index] = op.sticker;
    } else if (op.type === 'sticker-remove') data.stickers.splice(op.index, 1);
    else if (op.type === 'glitter') {
      data.glitter = data.glitter.filter((g) => g !== op.regionId);
      if (op.on) data.glitter.push(op.regionId);
    } else if (op.type === 'clear') {
      data.fills = {};
      data.strokes = [];
      data.stickers = [];
      data.glitter = [];
    }
  }
  return sanitizeArtworkData(room.manifest, data);
}

function publicRoom(room) {
  return {
    code: room.code,
    hostId: room.hostId,
    pictureId: room.picture.id,
    maxPlayers: COLLAB_MAX_PLAYERS,
    players: [...room.players.values()].map((p) => ({ ...p.profile, color: p.color })),
  };
}

const CURSOR_COLORS = ['#FF5F7E', '#2B9BF4', '#4CD787', '#FF9F43'];

export function registerCollab(io, socket) {
  const uid = socket.data.userId;
  const on = bindSocketHandlers(socket, 'collab');
  const reply = (cb, payload) => typeof cb === 'function' && cb(payload);
  const current = () => rooms.get(userRoom.get(uid));
  const channel = (room) => `collab:${room.code}`;

  function join(room) {
    let p = room.players.get(uid);
    if (!p) {
      const used = new Set([...room.players.values()].map((x) => x.color));
      p = { profile: socket.data.user, sockets: new Set(), color: CURSOR_COLORS.find((c) => !used.has(c)) || '#7D5FFF' };
      room.players.set(uid, p);
    }
    clearTimeout(room.expire); // có người vào lại thì huỷ lịch xoá phòng
    p.sockets.add(socket.id);
    userRoom.set(uid, room.code);
    socket.join(channel(room));
    io.to(channel(room)).emit('collab:room', publicRoom(room));
  }

  function leave(room) {
    const p = room.players.get(uid);
    if (!p) return;
    socket.leave(channel(room));
    p.sockets.delete(socket.id);
    if (p.sockets.size) return;
    room.players.delete(uid);
    userRoom.delete(uid);
    if (!room.players.size) {
      // Phòng vắng người: giữ thêm một lúc rồi mới xoá, để bé vừa tạo phòng xong (chuyển trang → rời → vào lại) hoặc mất mạng
      // thoáng chốc vẫn vào lại được đúng mã phòng, thay vì báo "không tìm thấy phòng".
      clearTimeout(room.expire);
      room.expire = setTimeout(() => {
        if (!room.players.size) rooms.delete(room.code);
      }, EMPTY_ROOM_GRACE_MS);
      room.expire.unref?.();
      return;
    }
    if (room.hostId === uid) room.hostId = room.players.keys().next().value;
    io.to(channel(room)).emit('collab:room', publicRoom(room));
  }

  on('collab:create', async (p, cb) => {
    const user = await User.findById(uid);
    if (!user?.nickname) return reply(cb, { error: 'nickname_required' });
    const picture = await Picture.findPicture(Number(p?.pictureId));
    if (!picture) return reply(cb, { error: 'picture_not_found' });
    if (!(await canUsePicture(user, picture))) return reply(cb, { error: 'card_not_owned' });
    const old = current();
    if (old) leave(old);
    let code;
    do code = randomCode(6);
    while (rooms.has(code));
    const room = { code, hostId: uid, picture, manifest: Picture.manifestOf(picture), players: new Map(), ops: [], seq: 0 };
    rooms.set(code, room);
    join(room);
    reply(cb, { room: publicRoom(room), picture: Picture.toClient(picture), data: stateOf(room) });
  });

  on('collab:join', async (p, cb) => {
    const room = rooms.get(
      String(p?.code || '')
        .trim()
        .toUpperCase(),
    );
    if (!room) return reply(cb, { error: 'room_not_found' });
    if (!(await User.findById(uid))?.nickname) return reply(cb, { error: 'nickname_required' });
    if (!room.players.has(uid) && room.players.size >= COLLAB_MAX_PLAYERS) return reply(cb, { error: 'room_full' });
    const old = current();
    if (old && old !== room) leave(old);
    join(room);
    reply(cb, { room: publicRoom(room), picture: Picture.toClient(room.picture), data: stateOf(room) });
  });

  on('collab:op', (op) => {
    const room = current();
    if (!room || !op || room.ops.length >= MAX_OPS) return;
    const clean = { id: ++room.seq, by: uid, type: op.type };
    const ids = room.manifest.regions;
    if (op.type === 'fill' || op.type === 'glitter') {
      if (!ids.some((r) => r.id === op.regionId)) return;
      clean.regionId = op.regionId;
      if (op.type === 'fill') {
        if (!/^#[0-9a-fA-F]{6}$/.test(op.color || '')) return;
        clean.color = op.color;
      } else clean.on = !!op.on;
    } else if (op.type === 'stroke') {
      const s = sanitizeArtworkData(room.manifest, { strokes: [op.stroke] }).strokes[0];
      if (!s?.points.length) return;
      clean.stroke = s;
      const f = op.fill;
      if (f && ids.some((r) => r.id === f.regionId) && (f.color === null || /^#[0-9a-fA-F]{6}$/.test(f.color || ''))) {
        clean.fill = { regionId: f.regionId, color: f.color ? f.color.toUpperCase() : null };
      }
    } else if (op.type === 'sticker') {
      const s = sanitizeArtworkData(room.manifest, { stickers: [op.sticker] }).stickers[0];
      if (!s) return;
      clean.sticker = s;
    } else if (op.type === 'sticker-update' || op.type === 'sticker-remove') {
      if (!Number.isInteger(op.index) || op.index < 0 || op.index > 200) return;
      clean.index = op.index;
      if (op.type === 'sticker-update') {
        const s = sanitizeArtworkData(room.manifest, { stickers: [op.sticker] }).stickers[0];
        if (!s) return;
        clean.sticker = s;
      }
    } else if (op.type !== 'clear') return;
    room.ops.push(clean);
    socket.to(channel(room)).emit('collab:op', clean);
  });

  // Undo: bé chỉ hoàn tác được thao tác của chính mình.
  on('collab:undo', () => {
    const room = current();
    if (!room) return;
    for (let i = room.ops.length - 1; i >= 0; i--) {
      if (room.ops[i].by === uid) {
        room.ops.splice(i, 1);
        io.to(channel(room)).emit('collab:state', stateOf(room));
        return;
      }
    }
  });

  on('collab:cursor', (pos) => {
    const room = current();
    if (!room || !Number.isFinite(pos?.x) || !Number.isFinite(pos?.y)) return;
    socket.to(channel(room)).volatile.emit('collab:cursor', { userId: uid, x: pos.x, y: pos.y, color: room.players.get(uid)?.color });
  });

  // Lưu tranh chung vào Lịch sử của mọi bé đang trong phòng.
  on('collab:save', async (payload, cb) => {
    const room = current();
    if (!room) return reply(cb, { error: 'room_not_found' });
    const data = stateOf(room);
    if (!Object.keys(data.fills).length && !data.strokes.length) return reply(cb, { error: 'empty' });
    const thumb =
      typeof payload?.thumbnail === 'string' && payload.thumbnail.startsWith('data:image/') && payload.thumbnail.length < 900 * 1024
        ? payload.thumbnail
        : null;
    for (const memberId of room.players.keys()) {
      await Artwork.create({ userId: memberId, pictureId: room.picture.id, mode: 'collab', data, thumbnail: thumb, status: 'completed' });
      const events = await progression.record(memberId, 'collab_join');
      io.to(`user:${memberId}`).emit('collab:saved', { by: socket.data.user, events });
    }
    reply(cb, { ok: true });
  });

  // Mời một người bạn (đã kết bạn) vào phòng đang ở. Người được mời nhận popup "Tèo mời bạn vào phòng tô tranh cùng".
  on('collab:invite', async (p, cb) => {
    const room = current();
    const to = Number(p?.toUserId);
    if (!room) return reply(cb, { error: 'room_not_found' });
    if (!Number.isInteger(to) || to === uid) return reply(cb, { error: 'invalid_friend' });
    if (!(await areFriends(uid, to))) return reply(cb, { error: 'not_friends' });
    if (room.players.has(to)) return reply(cb, { error: 'already_in_room' });
    if (room.players.size >= COLLAB_MAX_PLAYERS) return reply(cb, { error: 'room_full' });
    const key = `${uid}:${to}`;
    const now = Date.now();
    if ((inviteBlocks.get(key) || 0) > now) return reply(cb, { error: 'invite_blocked' });
    if (now - (lastInvite.get(key) || 0) < INVITE_GAP_MS) return reply(cb, { error: 'invite_too_fast' });
    const online = await io.in(`user:${to}`).fetchSockets();
    if (!online.length) return reply(cb, { error: 'friend_offline' });
    lastInvite.set(key, now);
    io.to(`user:${to}`).emit('collab:invite', { code: room.code, from: socket.data.user, pictureId: room.picture.id, at: now });
    reply(cb, { ok: true });
  });

  // Người được mời từ chối; tick "chặn" thì người mời không mời lại được trong 5 phút.
  on('collab:invite-decline', async (p, cb) => {
    const from = Number(p?.fromUserId);
    if (!Number.isInteger(from) || !(await areFriends(uid, from))) return reply(cb, { ok: true });
    const block = !!p?.block;
    if (block) inviteBlocks.set(`${from}:${uid}`, Date.now() + INVITE_BLOCK_MS);
    io.to(`user:${from}`).emit('collab:invite-declined', { by: socket.data.user, blocked: block });
    reply(cb, { ok: true });
  });

  on('collab:leave', (_p, cb) => {
    const room = current();
    if (room) leave(room);
    reply(cb, { ok: true });
  });

  on('disconnect', () => {
    const room = current();
    if (room) leave(room);
  });
}
