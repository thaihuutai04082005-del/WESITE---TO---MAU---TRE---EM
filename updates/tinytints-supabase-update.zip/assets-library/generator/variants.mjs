// Tầng 3: biến thể tư thế / cảm xúc / hoạt động, và 4 cấp thẻ Gacha (C/B/A/S).
// Mỗi biến thể = biểu cảm khuôn mặt + cảnh nền + (tuỳ chọn) biến đổi tư thế của chủ thể.
import { E, C, R, P, D, deco, line, softLines, star, skyStar, heart, cloud, drop, arcBand, smallFlower, butterfly } from './shapes.mjs';

const V = (slug, vi, en, opts) => ({ slug, name: { vi, en }, ...opts });

export const THEME_VARIANTS = {
  'dong-vat': [
    V('vui-ve', 'vui vẻ', 'happy', { expr: 'happy', scene: ['sun', 'clouds'] }),
    V('tuc-gian', 'tức giận', 'angry', { expr: 'angry', scene: ['stormCloud'] }),
    V('ngu-ngon', 'ngủ ngon', 'sleeping', { expr: 'sleep', scene: ['night', 'zzz'] }),
    V('le-luoi', 'thè lưỡi tinh nghịch', 'playful tongue', { expr: 'tongue', scene: ['clouds', 'flowers', 'butterfly'] }),
    V('chay-nhay', 'chạy nhảy', 'jumping', {
      expr: 'happy',
      scene: ['sun', 'motion', 'shadow'],
      transform: { ty: -48, rot: -7, px: 300, py: 400 },
    }),
  ],
  'xe-co': [
    V('vui-ve', 'vui vẻ', 'happy', { expr: 'happy', scene: ['sun', 'clouds'] }),
    V('chay-nhanh', 'chạy nhanh', 'speeding', { expr: 'happy', scene: ['clouds', 'speed'], transform: { rot: -3, px: 300, py: 450 } }),
    V('ban-dem', 'ban đêm', 'at night', { expr: 'happy', scene: ['night'] }),
    V('troi-mua', 'trời mưa', 'in the rain', { expr: 'surprised', scene: ['rain'] }),
    V('nghi-ngoi', 'nghỉ ngơi', 'resting', { expr: 'sleep', scene: ['sunset', 'zzz'] }),
  ],
  'thien-nhien': [
    V('vui-ve', 'vui vẻ', 'happy', { expr: 'happy', scene: ['sun', 'clouds'] }),
    V('ngu-ngon', 'ngủ ngon', 'sleeping', { expr: 'sleep', scene: ['night', 'zzz'] }),
    V('troi-mua', 'trời mưa', 'in the rain', { expr: 'surprised', scene: ['rain'] }),
    V('co-buom', 'có bướm bay', 'with butterflies', { expr: 'tongue', scene: ['sun', 'butterfly', 'flowers'] }),
    V('dung-dua', 'đung đưa trong gió', 'swaying in the wind', {
      expr: 'happy',
      scene: ['clouds', 'wind'],
      transform: { rot: 5, px: 300, py: 480 },
    }),
  ],
  'trai-cay': [
    V('vui-ve', 'vui vẻ', 'happy', { expr: 'happy', scene: ['sun', 'clouds'] }),
    V('ngac-nhien', 'ngạc nhiên', 'surprised', { expr: 'surprised', scene: ['clouds', 'flowers'] }),
    V('ngu-ngon', 'ngủ ngon', 'sleeping', { expr: 'sleep', scene: ['night', 'zzz'] }),
    V('tinh-nghich', 'tinh nghịch', 'cheeky', { expr: 'tongue', scene: ['sun', 'butterfly'] }),
    V('nhay-mua', 'nhảy múa', 'dancing', { expr: 'happy', scene: ['sun', 'motion', 'shadow'], transform: { ty: -40, rot: 8, px: 300, py: 400 } }),
  ],
  'nha-cua': [
    V('ban-ngay', 'ban ngày', 'daytime', { expr: null, scene: ['sun', 'clouds'] }),
    V('ban-dem', 'ban đêm', 'at night', { expr: null, scene: ['night'] }),
    V('troi-mua', 'trời mưa', 'rainy day', { expr: null, scene: ['rain'] }),
    V('mua-dong', 'mùa đông', 'winter', { expr: null, scene: ['snow', 'snowman'] }),
    V('mua-xuan', 'mùa xuân', 'spring', { expr: null, scene: ['sun', 'flowers', 'butterfly'] }),
  ],
};

/** Biến thể thẻ Gacha: tranh mở rộng, càng hiếm càng nhiều chi tiết. */
export const CARD_VARIANTS = [
  V('the-c-doi-mu', 'đội mũ tiệc', 'party hat', { rarity: 'C', expr: 'happy', scene: ['sun', 'clouds', 'hat'] }),
  V('the-b-bong-bay', 'với bóng bay', 'with balloons', { rarity: 'B', expr: 'happy', scene: ['clouds', 'balloons', 'hat', 'confetti'] }),
  V('the-a-cau-vong', 'dưới cầu vồng', 'under the rainbow', {
    rarity: 'A',
    expr: 'tongue',
    scene: ['rainbow', 'clouds', 'stars', 'flowers', 'butterfly'],
  }),
  V('the-s-vuong-mien', 'vương miện hoàng gia', 'royal crown', {
    rarity: 'S',
    expr: 'happy',
    scene: ['rainbow', 'stars', 'crown', 'balloons', 'hearts', 'confetti', 'flowers'],
  }),
];

// ----------------- Cảnh nền -----------------

export const SKY = { day: '#BDE6FF', night: '#2C3E74', sunset: '#FFD3A5', rain: '#A9C4D6', snow: '#CFE3F2', space: '#243B6B' };
export const GROUND = { grass: '#8BD17C', night: '#2F6B3F', snow: '#E3F2FD', water: '#5DADE2', waterNight: '#1F4E79', rock: '#B7BCC6', sand: '#F6D98B', ice: '#DDF1FB', court: '#7FC8A9' };

export function groundItem(kind, color) {
  if (kind === 'rock') {
    return D('mat-dat-hanh-tinh', 'M 0 468 Q 120 450 240 462 Q 380 476 480 456 Q 550 444 600 452 L 600 600 L 0 600 Z', color);
  }
  if (kind === 'water') {
    return D('mat-nuoc', 'M 0 440 Q 75 425 150 440 Q 225 455 300 440 Q 375 425 450 440 Q 525 455 600 440 L 600 600 L 0 600 Z', color);
  }
  return D('nen-dat', 'M 0 470 Q 150 440 300 465 Q 450 490 600 455 L 600 600 L 0 600 Z', color);
}

export function sceneParts(names, obj) {
  const back = [];
  const mid = [];
  const front = [];
  const subjectExtra = [];
  const has = (n) => names.includes(n);
  const hat = obj.hat;

  if (has('rainbow')) {
    ['#FF5F5F', '#FF9F43', '#FFD54F', '#4CD787', '#4FA3E0', '#7D5FFF'].forEach((c, k) =>
      back.push(arcBand(`cau-vong-${k + 1}`, 300, 470, 290 - 16 * k, 274 - 16 * k, c)),
    );
  }
  if (has('sun')) {
    back.push(Object.assign(star('tia-nang', 510, 92, 72, 50, '#FFB74D', 12), { optional: true, group: 'mat-troi-canh' }));
    back.push(Object.assign(C('mat-troi', 510, 92, 42, '#FFD54F'), { optional: true, group: 'mat-troi-canh' }));
  }
  if (has('night')) {
    back.push(D('mat-trang', 'M 490 50 C 412 56 412 164 490 170 C 452 146 452 76 490 50 Z', '#FFE066'));
    [[80, 70], [190, 130], [350, 60], [560, 230], [50, 240]].forEach(([x, y], k) =>
      back.push(star(`ngoi-sao-${k + 1}`, x, y, 15, 7, '#FFE066')),
    );
  }
  if (has('stars')) {
    [[70, 90], [540, 70], [520, 240], [90, 260]].forEach(([x, y], k) => back.push(skyStar(`sao-lap-lanh-${k + 1}`, x, y, 17, 8, '#FFD700')));
  }
  if (has('clouds')) {
    // Mây trang trí: chạm vào hình/dây khác thì build.mjs bỏ đi.
    back.push(Object.assign(cloud('may-1', 110, 110, 0.75), { optional: true, group: 'may-1' }));
    back.push(Object.assign(cloud('may-2', 330, 70, 0.6), { optional: true, group: 'may-2' }));
  }
  if (has('stormCloud')) {
    back.push(cloud('may-den', 470, 110, 0.9, '#90A4AE'));
    back.push(P('tia-set', [[470, 150], [448, 200], [468, 200], [452, 245], [492, 190], [472, 190], [486, 150]], '#FFD54F'));
    back.push(cloud('may-1', 120, 90, 0.6));
  }
  if (has('rain')) {
    back.push(cloud('may-mua-1', 140, 100, 0.95, '#B0BEC5'));
    back.push(cloud('may-mua-2', 460, 90, 0.95, '#B0BEC5'));
    [[70, 190], [130, 230], [200, 185], [400, 180], [470, 225], [540, 185], [100, 300], [510, 310]].forEach(([x, y], k) =>
      front.push(drop(`giot-mua-${k + 1}`, x, y, 1)),
    );
    mid.push(E('vung-nuoc', 480, 535, 70, 16, '#5DADE2'));
  }
  if (has('snow')) {
    [[60, 80], [150, 150], [250, 60], [360, 120], [470, 60], [550, 150], [80, 250], [520, 280], [420, 220], [180, 260]].forEach(
      ([x, y], k) => front.push(C(`bong-tuyet-${k + 1}`, x, y, 8, '#FFFFFF')),
    );
  }
  if (has('flowers')) {
    const petals = ['#FF7AA2', '#7D5FFF', '#FF9F43', '#4FA3E0'];
    [[70, 515], [150, 548], [455, 548], [535, 512]].forEach(([x, y], k) => mid.push(...smallFlower(`hoa-nho-${k + 1}`, x, y, petals[k])));
  }
  if (has('shadow')) mid.push(E('bong-do', 300, 505, 100, 16, '#B7C3CC'));
  if (has('snowman')) {
    mid.push(
      C('nguoi-tuyet-duoi', 80, 478, 38, '#FFFFFF'),
      C('nguoi-tuyet-tren', 80, 418, 26, '#FFFFFF'),
      R('mu-nguoi-tuyet', 63, 372, 34, 26, 3, '#2F3640'),
      R('vanh-mu', 54, 394, 52, 8, 3, '#2F3640'),
      P('mui-ca-rot', [[80, 420], [106, 426], [80, 430]], '#FF8A65'),
      deco('<circle cx="72" cy="410" r="3" fill="#1B2A38"/><circle cx="88" cy="410" r="3" fill="#1B2A38"/>'),
    );
  }
  if (has('butterfly')) front.push(...butterfly('buom', 95, 330, 1.1), ...butterfly('buom-nho', 510, 300, 0.8));
  if (has('balloons')) {
    front.push(
      line('M 90 190 Q 100 280 80 380 M 150 150 Q 140 260 150 360 M 515 175 Q 505 270 525 380', 2),
      E('bong-bay-1', 90, 150, 32, 40, '#FF5F7E'),
      E('bong-bay-2', 150, 108, 28, 36, '#4FA3E0'),
      E('bong-bay-3', 515, 135, 32, 40, '#FFC94D'),
    );
  }
  if (has('hearts')) {
    [[60, 380], [545, 360], [240, 90]].forEach(([x, y], k) => front.push(heart(`trai-tim-${k + 1}`, x, y, 1.1, '#FF5F7E')));
  }
  if (has('confetti')) {
    const cs = ['#FF5F7E', '#4CD787', '#7D5FFF', '#FF9F43', '#4FA3E0', '#FFD54F'];
    [[40, 40], [220, 40], [400, 30], [580, 40], [30, 440], [575, 450]].forEach(([x, y], k) =>
      front.push(R(`hoa-giay-${k + 1}`, x - 7, y - 4, 14, 8, 2, cs[k])),
    );
  }
  if (has('motion')) front.push(...softLines('M 110 280 L 60 280 M 120 330 L 50 330 M 110 380 L 60 380 M 490 300 L 540 300 M 495 350 L 555 350', 5));
  if (has('speed')) {
    front.push(...softLines('M 100 300 L 30 300 M 90 350 L 10 350 M 100 400 L 40 400', 6));
    mid.push(C('bui-1', 110, 455, 18, '#D6DEE6'), C('bui-2', 80, 440, 13, '#D6DEE6'), C('bui-3', 60, 462, 10, '#D6DEE6'));
  }
  if (has('wind')) {
    front.push(...softLines('M 40 200 Q 90 180 140 200 Q 170 212 160 230 M 460 150 Q 510 130 560 150 M 480 260 Q 530 240 580 260', 4));
    front.push(E('la-bay-1', 520, 200, 12, 7, '#4CAF50', 30), E('la-bay-2', 90, 150, 12, 7, '#4CAF50', -20));
  }
  // ---- Cảnh nền cho bộ chủ đề mới ----
  if (has('space')) {
    [[60, 60], [170, 120], [260, 40], [420, 90], [560, 50], [540, 210], [40, 230], [330, 150]].forEach(([x, y], k) =>
      back.push(star(`sao-${k + 1}`, x, y, k % 2 ? 9 : 13, k % 2 ? 4 : 6, '#FFE066')),
    );
  }
  if (has('planet')) {
    back.push(C('hanh-tinh', 505, 115, 50, '#FF8A65'), C('ho-hanh-tinh-1', 488, 100, 12, '#E57350'), C('ho-hanh-tinh-2', 522, 132, 8, '#E57350'));
  }
  if (has('craters')) {
    mid.push(E('mieng-ho-1', 110, 520, 50, 14, '#9AA1AD'), E('mieng-ho-2', 480, 545, 40, 11, '#9AA1AD'), E('mieng-ho-3', 300, 575, 30, 8, '#9AA1AD'));
  }
  if (has('flag')) {
    mid.push(R('can-co', 76, 330, 8, 150, 3, '#BFC8D0'), P('co', [[84, 332], [150, 350], [84, 370]], '#FF5F7E'));
  }
  if (has('station')) {
    back.push(
      R('tam-pin-trai', 60, 96, 110, 44, 4, '#4FA3E0'),
      R('tam-pin-phai', 250, 96, 110, 44, 4, '#4FA3E0'),
      R('thanh-noi', 170, 112, 80, 12, 4, '#BFC8D0'),
      R('khoang-tram', 180, 82, 60, 72, 14, '#E3F0FF'),
      C('cua-so-tram', 210, 118, 14, '#FFE066'),
    );
    back.push(line('M 88 96 L 88 140 M 116 96 L 116 140 M 144 96 L 144 140 M 278 96 L 278 140 M 306 96 L 306 140 M 334 96 L 334 140', 2));
  }
  if (has('candyCanes')) {
    const cane = (id, x) => [
      D(id, `M ${x - 9} 470 L ${x - 9} 330 Q ${x - 9} 286 ${x + 26} 286 Q ${x + 60} 286 ${x + 60} 320 L ${x + 42} 320 Q ${x + 42} 304 ${x + 26} 304 Q ${x + 9} 304 ${x + 9} 330 L ${x + 9} 470 Z`, '#FFFFFF'),
    ];
    mid.push(...cane('keo-gay-trai', 60), ...cane('keo-gay-phai', 500));
    front.push(line('M 51 350 L 69 336 M 51 390 L 69 376 M 51 430 L 69 416 M 491 350 L 509 336 M 491 390 L 509 376 M 491 430 L 509 416', 5));
  }
  if (has('volcano')) {
    back.push(P('nui-lua', [[0, 450], [0, 430], [70, 260], [120, 260], [200, 460]], '#A1887F'));
    back.push(D('dung-nham', 'M 70 262 Q 95 230 120 262 L 110 300 Q 102 284 95 304 Q 88 284 80 300 Z', '#FF7043'));
    back.push(C('khoi-nui-lua-1', 90, 220, 18, '#D6DEE6'), C('khoi-nui-lua-2', 70, 190, 22, '#D6DEE6'));
  }
  if (has('goal')) {
    back.push(R('khung-thanh', 30, 300, 150, 170, 4, '#FFFFFF'), R('luoi-khung-thanh', 44, 314, 122, 156, 2, '#E3F0FF'));
    back.push(line('M 74 314 L 74 470 M 104 314 L 104 470 M 134 314 L 134 470 M 44 350 L 166 350 M 44 390 L 166 390 M 44 430 L 166 430', 2));
  }
  if (has('hoop')) {
    back.push(R('cot-bong-ro', 62, 200, 14, 280, 4, '#BFC8D0'), R('bang-bong-ro', 20, 150, 110, 76, 6, '#FFFFFF'), R('o-bang', 52, 176, 46, 32, 3, '#FFE0B5'));
    back.push(E('vong-ro', 112, 214, 34, 8, '#FF5F5F'), P('luoi-ro', [[80, 216], [144, 216], [132, 262], [92, 262]], '#F0F4F8'));
  }
  if (has('podium')) {
    mid.push(R('buc-hai', 60, 410, 150, 80, 6, '#BFC8D0'), R('buc-nhat', 210, 360, 180, 130, 6, '#FFD54F'), R('buc-ba', 390, 430, 150, 60, 6, '#E0A15A'));
  }
  if (has('bubbles')) {
    [[90, 260, 16], [130, 200, 10], [480, 240, 18], [520, 180, 11], [450, 320, 9]].forEach(([x, y, r], k) => front.push(C(`bong-nuoc-${k + 1}`, x, y, r, '#D6F0FF')));
  }
  if (has('zzz') && hat) {
    subjectExtra.push(
      deco(
        `<text x="${hat.x + 70}" y="${hat.y - 10}" font-family="Baloo 2, Nunito, sans-serif" font-weight="800" font-size="40" fill="#1B2A38" pointer-events="none">Z<tspan font-size="30" dy="-18">z</tspan><tspan font-size="22" dy="-14">z</tspan></text>`,
      ),
    );
  }
  if (has('hat') && hat) {
    const { x, y, s } = hat;
    subjectExtra.push(
      P('mu-tiec', [[x - 36 * s, y + 6 * s], [x, y - 82 * s], [x + 36 * s, y + 6 * s]], '#7D5FFF'),
      P('soc-mu', [[x - 22 * s, y - 28 * s], [x + 22 * s, y - 28 * s], [x + 14 * s, y - 48 * s], [x - 14 * s, y - 48 * s]], '#FFD54F'),
      C('bong-mu', x, y - 84 * s, 11 * s, '#FF5F7E'),
    );
  }
  if (has('crown') && hat) {
    const { x, y, s } = hat;
    subjectExtra.push(
      P(
        'vuong-mien',
        [[x - 48 * s, y + 6 * s], [x - 54 * s, y - 50 * s], [x - 26 * s, y - 22 * s], [x, y - 64 * s], [x + 26 * s, y - 22 * s], [x + 54 * s, y - 50 * s], [x + 48 * s, y + 6 * s]],
        '#FFD700',
      ),
      C('ngoc-giua', x, y - 14 * s, 9 * s, '#FF5F7E'),
      C('ngoc-trai', x - 30 * s, y - 6 * s, 7 * s, '#4FA3E0'),
      C('ngoc-phai', x + 30 * s, y - 6 * s, 7 * s, '#4CD787'),
    );
  }
  return { back, mid, front, subjectExtra };
}
