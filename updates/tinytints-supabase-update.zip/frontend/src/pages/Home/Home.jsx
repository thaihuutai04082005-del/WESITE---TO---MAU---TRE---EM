import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../../store/auth';
import { api } from '../../services/api';
import PictureView from '../../components/PictureView/PictureView';
import ProgressBar from '../../components/ProgressBar/ProgressBar';
import Icon from '../../components/Icon';
import { PlanBadge } from '../Payment/Plans';
import ModeGuide from '../../components/ModeGuide';
import { RankMedal, RANK_STYLE } from '../../components/RankBadge';
import HelloBear from '../../components/HelloBear';
import { ColorArt, TrophyArt, TogetherArt, GachaArt, BookArt, MissionArt, SunCloud } from '../../components/Illustrations';

// 5 tranh ở trang giới thiệu, theo thứ tự ô: chó (ô lớn), Chiến Binh Siêu Tốc, Tiên Cá Hải Lam, Xe Đua Phản Lực, búp bê.
// Ảnh bìa của mỗi chủ đề chính là tranh đầu tiên của chủ đề đó.
const LANDING_SLUGS = ['dong-vat-3-4', 'chien-binh-bien-hinh-9', 'tien-ca-phep-thuat-9', 'doi-xe-vu-tru', 'do-choi-3-5'];
const landingThemes = (themes) => {
  const picked = LANDING_SLUGS.map((slug) => themes.find((th) => th.slug === slug)).filter(Boolean);
  return picked.length === LANDING_SLUGS.length ? picked : themes.slice(0, 5);
};

function Landing() {
  const { t } = useTranslation();
  const [themes, setThemes] = useState([]);
  const [loadError, setLoadError] = useState(false);
  const [retry, setRetry] = useState(0);
  useEffect(() => {
    let active = true;
    setLoadError(false);
    api.get('/themes').then((r) => {
      if (!Array.isArray(r.themes)) throw new Error('Invalid themes response');
      if (active) setThemes(r.themes);
    }).catch(() => {
      if (active) setLoadError(true);
    });
    return () => { active = false; };
  }, [retry]);
  const features = ['creative', 'arena', 'gacha', 'together', 'storybook', 'safe'];
  return (
    <div className="bg-[#BFE8FF] bg-cover bg-fixed bg-center bg-no-repeat" style={{ backgroundImage: HOME_BG }}>
    <div className="page">
      {loadError && (
        <div role="status" className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-white/90 p-4 text-ink" data-testid="backend-unavailable">
          <p>{t('errors.backend_unavailable')}</p>
          <button type="button" className="btn-ghost" onClick={() => setRetry((n) => n + 1)}>{t('common.tryAgain')}</button>
        </div>
      )}
      <section className="grid items-center gap-6 py-6 md:grid-cols-2 md:py-12">
        <div>
          <h1 className="font-display text-4xl font-extrabold leading-tight md:text-6xl">{t('landing.title')}</h1>
          <p className="mt-3 text-lg text-muted md:text-xl">{t('landing.subtitle')}</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link to="/register" className="btn-primary text-xl" data-testid="cta-register">
              {t('landing.cta')}
            </Link>
            <Link to="/login" className="btn-ghost text-xl">
              {t('auth.login')}
            </Link>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {landingThemes(themes).map((th, i) => (
            <div key={th.slug} className={`card overflow-hidden p-1 ${i === 0 ? 'col-span-2 row-span-2' : ''}`}>
              <PictureView picture={th.cover} reveal className="rounded-2xl" />
            </div>
          ))}
        </div>
      </section>
      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {features.map((f) => (
          <div key={f} className="card p-5">
            <h3 className="font-display text-xl font-bold">{t(`landing.features.${f}.title`)}</h3>
            <p className="text-muted">{t(`landing.features.${f}.text`)}</p>
          </div>
        ))}
      </section>
    </div>
    </div>
  );
}

const HOME_BG = 'url(/home-bg.webp)';

const HOME_CARDS = [
  { to: '/color', key: 'color', icon: 'palette', Art: ColorArt, bg: 'linear-gradient(135deg,#DDEFFF 0%,#B7DCFF 100%)', accent: '#2B9BF4' },
  { to: '/arena', key: 'arena', icon: 'trophy', Art: TrophyArt, bg: 'linear-gradient(135deg,#FFE7D3 0%,#FFC8A2 100%)', accent: '#F07B2E' },
  { to: '/together', key: 'together', icon: 'heart', Art: TogetherArt, artSpace: '-mb-2 -mt-4 -ml-5 mr-10', bg: 'linear-gradient(135deg,#DDF7E2 0%,#A9E8B6 100%)', accent: '#2FA65A' },
  { to: '/gacha', key: 'gacha', icon: 'gift', Art: GachaArt, bg: 'linear-gradient(135deg,#EEE7FF 0%,#D2C2FF 100%)', accent: '#7D5FFF' },
  { to: '/storybooks', key: 'storybooks', icon: 'book', Art: BookArt, artSpace: '-mb-1 -mt-3 mr-14', bg: 'linear-gradient(135deg,#FFF5CF 0%,#FFE08F 100%)', accent: '#D99A00' },
  { to: '/missions', key: 'missions', icon: 'target', Art: MissionArt, bg: 'linear-gradient(135deg,#DDF4FF 0%,#B4E4FF 100%)', accent: '#138FA8' },
];

function HomeCard({ card, onInfo }) {
  const { t } = useTranslation();
  const { Art } = card;
  return (
    <div
      className="group relative grid min-h-44 grid-cols-[auto_minmax(0,1fr)] gap-3 overflow-hidden rounded-[28px] p-5 shadow-soft transition hover:-translate-y-1 hover:shadow-pop"
      style={{ background: card.bg }}
    >
      {/* Cả ô là 1 liên kết; nút "i" nằm trên cùng, tách riêng để không lồng nút trong liên kết. */}
      <Link to={card.to} className="absolute inset-0 z-0 rounded-[28px]" aria-label={t(`nav.${card.key}`)} data-testid={`tile-${card.key}`} />
      <div className="pointer-events-none relative z-10 flex flex-col justify-between gap-3">
        <span style={{ color: card.accent }}>
          <Icon name={card.icon} size={44} strokeWidth={2.6} />
        </span>
        <span className="whitespace-nowrap font-display text-[26px] font-extrabold leading-[1.1] text-ink">{t(`nav.${card.key}`)}</span>
      </div>
      <div className={`pointer-events-none relative ${card.artSpace || '-my-2 mr-12'}`}>
        <div className="absolute inset-0 transition duration-300 group-hover:scale-105">
          <Art />
        </div>
      </div>
      <button
        type="button"
        onClick={() => onInfo(card)}
        className="absolute right-3 top-3 z-20 flex h-10 w-10 items-center justify-center rounded-full border-2 border-white bg-white/75 font-display text-xl font-extrabold not-italic shadow-soft backdrop-blur transition hover:scale-110 hover:bg-white focus-visible:outline-none focus-visible:ring-4"
        style={{ color: card.accent, '--tw-ring-color': `${card.accent}55` }}
        aria-label={t('guide.open', { name: t(`nav.${card.key}`) })}
        title={t('guide.open', { name: t(`nav.${card.key}`) })}
        data-testid={`info-${card.key}`}
      >
        <span className="leading-none">i</span>
      </button>
      <span className="pointer-events-none absolute bottom-4 right-4 z-10 flex h-11 w-11 items-center justify-center rounded-full bg-white shadow-soft transition group-hover:translate-x-1" style={{ color: card.accent }}>
        <Icon name="arrow" size={22} strokeWidth={3} />
      </span>
    </div>
  );
}

function Dashboard() {
  const { t } = useTranslation();
  const user = useAuth((s) => s.user);
  const plan = useAuth((s) => s.plan);
  const [prog, setProg] = useState(null);
  const [guide, setGuide] = useState(null);
  // Tải cấp độ & hạng. Lỗi mạng/máy chủ thoáng qua (hay gặp ngay sau khi đăng nhập) thì tự thử lại, không để thanh này biến mất tới khi tải lại trang.
  const uid = user?.id;
  useEffect(() => {
    let alive = true;
    let timer;
    const load = (attempt = 0) =>
      api
        .get('/progression')
        .then((r) => alive && setProg(r))
        .catch(() => {
          if (alive && attempt < 4) timer = setTimeout(() => load(attempt + 1), 1000 * (attempt + 1));
        });
    load();
    const onVisible = () => document.visibilityState === 'visible' && load();
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      alive = false;
      clearTimeout(timer);
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, [uid]);
  const done = prog ? prog.missions.filter((m) => m.completed).length : 0;
  const rank = prog?.rank;

  return (
    <div className="bg-[#BFE8FF] bg-cover bg-fixed bg-center bg-no-repeat" style={{ backgroundImage: HOME_BG }}>
      <div className="page max-w-7xl space-y-6">
        {/* Lời chào + linh vật */}
        <section className="relative flex items-center gap-3 pt-2 sm:gap-6">
          <div className="relative h-28 w-24 shrink-0 sm:h-40 sm:w-36">
            <HelloBear className="h-full w-full" />
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="font-display text-4xl font-extrabold leading-none text-ink sm:text-5xl lg:text-6xl" style={{ WebkitTextStroke: "6px #fff", paintOrder: "stroke fill", strokeLinejoin: "round" }} data-testid="home-hello">
              {t('home.hello', { name: user.nickname })}
            </h1>
            <p className="mt-2 text-lg text-muted sm:text-2xl">{t('home.subtitle')}</p>
          </div>
          <div className="hidden flex-col items-end gap-2 lg:flex">
            <PlanBadge plan={plan} />
          </div>
          <SunCloud className="pointer-events-none absolute -top-2 right-0 hidden h-24 w-32 opacity-90 lg:block lg:translate-x-6 lg:-translate-y-6" />
        </section>
        <div className="lg:hidden">
          <PlanBadge plan={plan} />
        </div>

        {/* 6 thẻ chức năng */}
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 lg:gap-5">
          {HOME_CARDS.map((c) => (
            <HomeCard key={c.key} card={c} onInfo={setGuide} />
          ))}
        </section>

        <ModeGuide card={guide} onClose={() => setGuide(null)} />

        {/* Lối vào Hội trường triển lãm: nền xanh dương sáng + mây mờ góc phải + ngôi sao vàng */}
        <Link to="/exhibition" className="group relative flex items-center gap-4 overflow-hidden rounded-[28px] bg-gradient-to-r from-[#2C66AE] via-[#3478BD] to-[#4F90CF] p-4 shadow-soft transition hover:-translate-y-1 hover:shadow-pop sm:p-5" data-testid="home-exhibition">
          <svg viewBox="0 0 300 100" preserveAspectRatio="xMaxYMax slice" className="pointer-events-none absolute inset-y-0 right-0 h-full w-72 sm:w-96" aria-hidden="true">
            <path d="M40 100 Q60 62 110 70 Q130 34 180 44 Q215 18 255 36 Q300 30 300 60 L300 100 Z" fill="#FFFFFF" opacity="0.1" />
            <path d="M110 100 Q130 78 170 82 Q190 58 230 64 Q262 48 300 66 L300 100 Z" fill="#FFFFFF" opacity="0.12" />
            <path d="M66 36 l3.2 -8 l3.2 8 l8 3.2 l-8 3.2 l-3.2 8 l-3.2 -8 l-8 -3.2 Z" fill="#FFD54F" />
          </svg>
          <span className="relative flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-[#FFD54F] text-[#1F3A6B] shadow-soft">
            <Icon name="museum" size={30} strokeWidth={2.4} />
          </span>
          <span className="relative min-w-0 flex-1">
            <span className="block font-display text-2xl font-extrabold leading-tight text-white">{t('exhibition.title')}</span>
          </span>
          <span className="relative flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-white text-[#1F3A6B] shadow-soft transition group-hover:translate-x-1">
            <Icon name="arrow" size={22} strokeWidth={3} />
          </span>
        </Link>

        {/* Cấp độ & Rank: chỉ để bé xem cấp và điểm hiện tại (không bấm chuyển trang) */}
        {prog && (
          <section className="card grid gap-5 p-5 md:grid-cols-2 md:gap-8">
            <div className="flex items-center gap-4" data-testid="home-level">
              <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-[#E4F6E8] text-[#2FA65A]">
                <Icon name="mountain" size={32} strokeWidth={2.4} />
              </span>
              <div className="min-w-0 flex-1">
                <div className="mb-1.5 flex items-baseline justify-between gap-2">
                  <span className="font-display text-xl font-extrabold">{t('home.level', { level: prog.level })}</span>
                  <span className="text-sm font-bold text-muted">
                    {done}/{prog.missions.length} {t('home.missions')}
                  </span>
                </div>
                <ProgressBar value={done} max={prog.missions.length} color="linear-gradient(90deg,#4CD787,#2FA65A)" height={12} />
              </div>
            </div>
            <div className="flex items-center gap-4" data-testid="home-rank">
              <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl" style={{ background: RANK_STYLE[rank.key].bg }}>
                <RankMedal rank={rank.key} size={48} />
              </span>
              <div className="min-w-0 flex-1">
                <div className="mb-1.5 flex items-baseline justify-between gap-2">
                  <span className="font-display text-xl font-extrabold">
                    {t('home.rank')} {t(`rank.${rank.key}`)}
                  </span>
                  <span className="text-sm font-bold text-muted">
                    {rank.next ? `${rank.points}/${rank.next.min}` : rank.points} {t('rank.pts')}
                  </span>
                </div>
                <ProgressBar
                  value={rank.points - rank.currentMin}
                  max={rank.next ? rank.next.min - rank.currentMin : 1}
                  color={`linear-gradient(90deg,${RANK_STYLE[rank.key].fill},${RANK_STYLE[rank.key].ring})`}
                  height={12}
                />
              </div>
            </div>
          </section>
        )}
      </div>
    </div>
  );
}

export default function Home() {
  const user = useAuth((s) => s.user);
  return user ? <Dashboard /> : <Landing />;
}
